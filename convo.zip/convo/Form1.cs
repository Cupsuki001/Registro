using System.Data;
using System.Data.SqlClient;

namespace convo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BTNbs_Click(object sender, EventArgs e)
        {
            conexion.conectr();
            MessageBox.Show("Se conecto a la base de datos");

            dataGridView1.DataSource = llenar();
        }

        public DataTable llenar()
        {
            conexion.conectr();
            DataTable dt = new DataTable();
            string consulta = "select *from datos";
            SqlCommand cmd = new SqlCommand(consulta, conexion.conectr());

            SqlDataAdapter da = new SqlDataAdapter(cmd);

            da.Fill(dt);
            return dt;
        }

        private void BTNing_Click(object sender, EventArgs e)
        {
            conexion.conectr();
            string insertar = "insert into datos (CDG,NMB,APD,DRC) values (@CDG,@NMB,@APD,@DRC)";
            SqlCommand cmd1 = new SqlCommand(insertar, conexion.conectr());
            cmd1.Parameters.AddWithValue("@CDG", TXBcodig.Text);
            cmd1.Parameters.AddWithValue("@NMB", TXBnom.Text);
            cmd1.Parameters.AddWithValue("@APD", TXBapell.Text);
            cmd1.Parameters.AddWithValue("@DRC", TXBdirecc.Text);

            cmd1.ExecuteNonQuery();
            MessageBox.Show("Los datos fueron ingresados");

            dataGridView1.DataSource = llenar();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                TXBcodig.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                TXBnom.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                TXBapell.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                TXBdirecc.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();

            }
            catch
            {
                MessageBox.Show("ERROR");

            }
        }

        private void BTNmodif_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = conexion.conectr())
            {
                string modificar = "UPDATE datos SET NMB=@NMB, APD=@APD, DRC=@DRC WHERE CDG=@CDG";
                SqlCommand cmd2 = new SqlCommand(modificar, connection);

                cmd2.Parameters.AddWithValue("@CDG", TXBcodig.Text);
                cmd2.Parameters.AddWithValue("@NMB", TXBnom.Text);
                cmd2.Parameters.AddWithValue("@APD", TXBapell.Text);
                cmd2.Parameters.AddWithValue("@DRC", TXBdirecc.Text);

                cmd2.ExecuteNonQuery();
            }

            MessageBox.Show("Los datos fueron modificados");

            dataGridView1.DataSource = llenar();
        }

        private void BTNelmi_Click(object sender, EventArgs e)
        {
            conexion.conectr();
            string eliminar = "DELETE FROM datos WHERE CDG=@CDG";
            SqlCommand cmd3 = new SqlCommand(eliminar,conexion.conectr());
            cmd3.Parameters.AddWithValue("@CDG", TXBcodig.Text);

            cmd3.ExecuteNonQuery();
            MessageBox.Show("Se elimo con exito");

            dataGridView1.DataSource = llenar();
        }
    }
}
