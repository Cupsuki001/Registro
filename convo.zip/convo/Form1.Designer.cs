﻿namespace convo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            TXBnom = new TextBox();
            TXBapell = new TextBox();
            TXBcodig = new TextBox();
            TXBdirecc = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            BTNing = new Button();
            BTNbusc = new Button();
            BTNelmi = new Button();
            BTNsalir = new Button();
            BTNbs = new Button();
            BTNmodif = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(54, 235);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(705, 188);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // TXBnom
            // 
            TXBnom.Location = new Point(75, 67);
            TXBnom.Name = "TXBnom";
            TXBnom.Size = new Size(125, 27);
            TXBnom.TabIndex = 1;
            // 
            // TXBapell
            // 
            TXBapell.Location = new Point(296, 67);
            TXBapell.Name = "TXBapell";
            TXBapell.Size = new Size(125, 27);
            TXBapell.TabIndex = 2;
            // 
            // TXBcodig
            // 
            TXBcodig.Location = new Point(75, 160);
            TXBcodig.Name = "TXBcodig";
            TXBcodig.Size = new Size(125, 27);
            TXBcodig.TabIndex = 3;
            // 
            // TXBdirecc
            // 
            TXBdirecc.Location = new Point(296, 160);
            TXBdirecc.Name = "TXBdirecc";
            TXBdirecc.Size = new Size(125, 27);
            TXBdirecc.TabIndex = 4;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(78, 39);
            label1.Name = "label1";
            label1.Size = new Size(64, 20);
            label1.TabIndex = 5;
            label1.Text = "Nombre";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(296, 32);
            label2.Name = "label2";
            label2.Size = new Size(64, 20);
            label2.TabIndex = 6;
            label2.Text = "apellido";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(73, 128);
            label3.Name = "label3";
            label3.Size = new Size(58, 20);
            label3.TabIndex = 7;
            label3.Text = "Codigo";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(310, 137);
            label4.Name = "label4";
            label4.Size = new Size(72, 20);
            label4.TabIndex = 8;
            label4.Text = "Direccion";
            // 
            // BTNing
            // 
            BTNing.Location = new Point(510, 64);
            BTNing.Name = "BTNing";
            BTNing.Size = new Size(94, 29);
            BTNing.TabIndex = 9;
            BTNing.Text = "Ingresar";
            BTNing.UseVisualStyleBackColor = true;
            BTNing.Click += BTNing_Click;
            // 
            // BTNbusc
            // 
            BTNbusc.Location = new Point(510, 160);
            BTNbusc.Name = "BTNbusc";
            BTNbusc.Size = new Size(94, 29);
            BTNbusc.TabIndex = 10;
            BTNbusc.Text = "Buscar";
            BTNbusc.UseVisualStyleBackColor = true;
            // 
            // BTNelmi
            // 
            BTNelmi.Location = new Point(676, 65);
            BTNelmi.Name = "BTNelmi";
            BTNelmi.Size = new Size(94, 29);
            BTNelmi.TabIndex = 11;
            BTNelmi.Text = "Eliminar";
            BTNelmi.UseVisualStyleBackColor = true;
            BTNelmi.Click += BTNelmi_Click;
            // 
            // BTNsalir
            // 
            BTNsalir.Location = new Point(676, 160);
            BTNsalir.Name = "BTNsalir";
            BTNsalir.Size = new Size(94, 29);
            BTNsalir.TabIndex = 12;
            BTNsalir.Text = "Salir";
            BTNsalir.UseVisualStyleBackColor = true;
            // 
            // BTNbs
            // 
            BTNbs.Location = new Point(788, 320);
            BTNbs.Name = "BTNbs";
            BTNbs.Size = new Size(94, 29);
            BTNbs.TabIndex = 13;
            BTNbs.Text = "BD";
            BTNbs.UseVisualStyleBackColor = true;
            BTNbs.Click += BTNbs_Click;
            // 
            // BTNmodif
            // 
            BTNmodif.Location = new Point(594, 119);
            BTNmodif.Name = "BTNmodif";
            BTNmodif.Size = new Size(94, 29);
            BTNmodif.TabIndex = 14;
            BTNmodif.Text = "Modificar";
            BTNmodif.UseVisualStyleBackColor = true;
            BTNmodif.Click += BTNmodif_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(911, 450);
            Controls.Add(BTNmodif);
            Controls.Add(BTNbs);
            Controls.Add(BTNsalir);
            Controls.Add(BTNelmi);
            Controls.Add(BTNbusc);
            Controls.Add(BTNing);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(TXBdirecc);
            Controls.Add(TXBcodig);
            Controls.Add(TXBapell);
            Controls.Add(TXBnom);
            Controls.Add(dataGridView1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private TextBox TXBnom;
        private TextBox TXBapell;
        private TextBox TXBcodig;
        private TextBox TXBdirecc;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button BTNing;
        private Button BTNbusc;
        private Button BTNelmi;
        private Button BTNsalir;
        private Button BTNbs;
        private Button BTNmodif;
    }
}
