﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace convo
{
    public class conexion
    {
        public static SqlConnection conectr()
        {
            SqlConnection cn = new SqlConnection("Server=DESKTOP-E4EN6EA\\SQLEXPRESS;Database=colegio;Integrated Security=True;");
            cn.Open();
            return cn;
        }
    }
}
